const products = [
  {id:1, name:"دورة Roblox Studio من الصفر", cat:"courses", tag:"دورة", price:89, from:false, accent:"#22e58b", accent2:"#22e58b44", icon:"R", image:"assets/course.png", desc:"تعلم Studio، بناء المابات، أساسيات Lua وأنظمة بسيطة خطوة بخطوة.", features:["أساسيات Studio","مدخل Lua","مشروع تطبيقي","ملفات تدريب"]},
  {id:2, name:"تصميم ماب احترافي", cat:"maps", tag:"مابات", price:249, from:true, accent:"#22f59a", accent2:"#22f59a44", icon:"▦", image:"assets/map.png", desc:"ماب مخصص حسب فكرتك: لوبي، PvP، رعب، RPG أو عالم مفتوح.", features:["تصميم مخصص","إضاءة وAtmosphere","Optimization","تعديلات متفق عليها"]},
  {id:3, name:"لعبة خاصة كاملة", cat:"custom", tag:"طلب خاص", price:799, from:true, accent:"#2ee89c", accent2:"#2ee89c44", icon:"◆", image:"assets/full-game.png", desc:"نبني تجربة Roblox متكاملة من الفكرة إلى نسخة قابلة للعب.", features:["ماب + أنظمة","UI أساسي","حفظ بيانات","تجهيز للنشر"]},
  {id:4, name:"حزمة مودلات Low Poly", cat:"models", tag:"مودلات", price:39, from:false, accent:"#39e68d", accent2:"#39e68d44", icon:"⬡", image:"assets/models.png", desc:"مجموعة مودلات نظيفة لألعاب المغامرات واللوبيات والمابات.", features:["20+ مودل","منظمة بمجلدات","ألوان قابلة للتعديل","جاهزة للاستيراد"]},
  {id:5, name:"حزمة سكربتات Gameplay", cat:"scripts", tag:"سكربتات", price:59, from:false, accent:"#19d98a", accent2:"#19d98a44", icon:"{ }", image:"assets/scripts.png", desc:"أنظمة جاهزة كبداية: Sprint، Stamina، Doors، Checkpoints والمزيد.", features:["Lua منظم","شرح تركيب","قابل للتعديل","بدون أكواد مشبوهة"]},
  {id:6, name:"تصميم واجهات UI", cat:"custom", tag:"تصميم", price:129, from:true, accent:"#25f2a0", accent2:"#25f2a044", icon:"UI", image:"assets/ui.png", desc:"واجهات متجر، لابي، Inventory وHUD بتصميم يناسب هوية لعبتك.", features:["تصميم مخصص","Transitions","Responsive UI","تسليم منظم"]},
];

const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
let cart = JSON.parse(localStorage.getItem("nexarift_cart") || "[]");
let user = JSON.parse(localStorage.getItem("nexarift_user") || "null");

function money(n){ return `${n.toLocaleString("ar-SA")} ر.س`; }
function toast(msg){
  const el=$("#toast"); el.textContent=msg; el.classList.add("show");
  clearTimeout(window.__toast); window.__toast=setTimeout(()=>el.classList.remove("show"),1800);
}
function productCard(p){
  return `<article class="product-card" data-id="${p.id}" data-cat="${p.cat}" style="--accent:${p.accent};--accent2:${p.accent2}">
    <div class="product-art"><img src="${p.image}" alt="${p.name}" loading="lazy"><div class="product-image-shade"></div><span class="art-chip">${p.tag}</span></div>
    <div class="product-body">
      <div class="product-meta"><h3>${p.name}</h3><span>${p.tag}</span></div>
      <p>${p.desc}</p>
      <div class="product-bottom">
        <div class="price"><small>${p.from?"يبدأ من":"السعر"}</small><b>${money(p.price)}</b></div>
        <button class="add-btn" data-add="${p.id}" aria-label="أضف للسلة">+</button>
      </div>
    </div>
  </article>`;
}
function renderProducts(filter="all"){
  $("#productGrid").innerHTML = products.filter(p=>filter==="all"||p.cat===filter).map(productCard).join("");
  bindProductEvents();
}
function bindProductEvents(){
  $$(".product-card").forEach(card=>card.addEventListener("click",e=>{
    if(e.target.closest("[data-add]")) return;
    openProduct(+card.dataset.id);
  }));
  $$("[data-add]").forEach(btn=>btn.addEventListener("click",e=>{
    e.stopPropagation(); addToCart(+btn.dataset.add);
  }));
}
function addToCart(id){
  const found=cart.find(x=>x.id===id);
  if(found) found.qty++;
  else cart.push({id,qty:1});
  persistCart(); toast("تمت الإضافة للسلة ✦");
}
function removeFromCart(id){
  cart=cart.filter(x=>x.id!==id); persistCart();
}
function persistCart(){
  localStorage.setItem("nexarift_cart",JSON.stringify(cart)); renderCart();
}
function renderCart(){
  const count=cart.reduce((a,b)=>a+b.qty,0); $("#cartCount").textContent=count;
  const wrap=$("#cartItems"), empty=$("#emptyCart"), foot=$("#cartFooter");
  if(!cart.length){wrap.innerHTML="";empty.style.display="block";foot.style.display="none";return;}
  empty.style.display="none";foot.style.display="block";
  wrap.innerHTML=cart.map(c=>{
    const p=products.find(x=>x.id===c.id);
    return `<div class="cart-item" style="--accent:${p.accent}">
      <div class="cart-thumb">${p.icon}</div>
      <div><h4>${p.name}</h4><small>${money(p.price)} × ${c.qty}</small></div>
      <button class="remove-item" data-remove="${p.id}">×</button>
    </div>`;
  }).join("");
  $$("[data-remove]").forEach(b=>b.onclick=()=>removeFromCart(+b.dataset.remove));
  const total=cart.reduce((sum,c)=>sum+(products.find(p=>p.id===c.id).price*c.qty),0);
  $("#cartTotal").textContent=money(total);
}
function openCart(){ $("#cartDrawer").classList.add("open"); $("#drawerBackdrop").classList.add("open"); }
function closeCart(){ $("#cartDrawer").classList.remove("open"); $("#drawerBackdrop").classList.remove("open"); }
function openModal(id){ $(id).classList.add("open"); document.body.style.overflow="hidden"; }
function closeModal(id){ $(id).classList.remove("open"); document.body.style.overflow=""; }

function openProduct(id){
  const p=products.find(x=>x.id===id);
  $("#productModalBody").innerHTML=`
    <div class="product-modal-hero" style="--accent:${p.accent};--accent2:${p.accent2}"><img src="${p.image}" alt="${p.name}"></div>
    <div class="product-modal-info">
      <div><span class="kicker">${p.tag}</span><h3>${p.name}</h3><p>${p.desc}</p></div>
      <b class="modal-price">${p.from?"من ":""}${money(p.price)}</b>
    </div>
    <div class="modal-features">${p.features.map(x=>`<span>✓ ${x}</span>`).join("")}</div>
    <button class="primary-btn full" id="modalAdd">أضف للسلة</button>`;
  $("#modalAdd").onclick=()=>{ addToCart(id); closeModal("#productModal"); openCart(); };
  openModal("#productModal");
}

$$(".filter").forEach(btn=>btn.onclick=()=>{
  $$(".filter").forEach(b=>b.classList.remove("active")); btn.classList.add("active");
  renderProducts(btn.dataset.filter);
});

$("#cartBtn").onclick=openCart; $("#drawerBackdrop").onclick=closeCart;
$('[data-close="cart"]').onclick=closeCart;

$("#menuBtn").onclick=()=>$("#mobileNav").classList.toggle("open");
$$(".mobile-nav a").forEach(a=>a.onclick=()=>$("#mobileNav").classList.remove("open"));

function updateLoginButton(){
  $("#loginBtn").textContent=user?user.name.split(" ")[0]:"دخول";
}
$("#loginBtn").onclick=()=>{
  if(user){ if(confirm(`مسجل باسم ${user.name}. تسجيل خروج؟`)){user=null;localStorage.removeItem("nexarift_user");updateLoginButton();toast("تم تسجيل الخروج");} }
  else openModal("#loginModal");
};
$("#loginForm").onsubmit=e=>{
  e.preventDefault();
  user={name:$("#nameInput").value.trim(),email:$("#emailInput").value.trim()};
  localStorage.setItem("nexarift_user",JSON.stringify(user)); updateLoginButton(); closeModal("#loginModal"); toast(`هلا ${user.name} ✦`);
};

$("#searchBtn").onclick=()=>{openModal("#searchModal");setTimeout(()=>$("#searchInput").focus(),50)};
$("#searchInput").oninput=e=>{
  const q=e.target.value.trim().toLowerCase();
  const list=q?products.filter(p=>(p.name+" "+p.desc+" "+p.tag).toLowerCase().includes(q)):[];
  $("#searchResults").innerHTML=list.length?list.map(p=>`<button class="search-result" data-search-id="${p.id}"><b>${p.name}</b><span>${money(p.price)}</span></button>`).join(""):(q?`<div class="search-result"><b>ما لقينا شيء مطابق</b></div>`:"");
  $$("[data-search-id]").forEach(b=>b.onclick=()=>{closeModal("#searchModal");openProduct(+b.dataset.searchId)});
};

$("#customOrderBtn").onclick=()=>openModal("#customModal");
$("#customForm").onsubmit=e=>{
  e.preventDefault();
  const order = {
    type:$("#customType").value, desc:$("#customDesc").value.trim(),
    budget:$("#customBudget").value, deadline:$("#customDeadline").value
  };
  localStorage.setItem("nexarift_custom_order",JSON.stringify(order));
  closeModal("#customModal");
  const text=`طلب خاص — NexaRift\nالنوع: ${order.type}\nالميزانية: ${order.budget}\nالمدة: ${order.deadline}\nالفكرة: ${order.desc}`;
  $("#checkoutSummary").textContent=text;
  $("#copyOrderBtn").dataset.copy=text;
  openModal("#checkoutModal");
};

$("#checkoutBtn").onclick=()=>{
  if(!cart.length) return;
  const lines=cart.map(c=>{const p=products.find(x=>x.id===c.id);return `• ${p.name} × ${c.qty} — ${money(p.price*c.qty)}`});
  const total=cart.reduce((sum,c)=>sum+(products.find(p=>p.id===c.id).price*c.qty),0);
  const text=`طلب من متجر NexaRift\n\n${lines.join("\n")}\n\nالإجمالي: ${money(total)}`;
  $("#checkoutSummary").textContent=text; $("#copyOrderBtn").dataset.copy=text;
  closeCart(); openModal("#checkoutModal");
};
$("#copyOrderBtn").onclick=async()=>{
  try{await navigator.clipboard.writeText($("#copyOrderBtn").dataset.copy||"");toast("تم نسخ تفاصيل الطلب");}
  catch{toast("حدد النص وانسخه يدويًا");}
};

const modalMap={product:"#productModal",login:"#loginModal",search:"#searchModal",custom:"#customModal",checkout:"#checkoutModal"};
$$("[data-close]").forEach(btn=>{
  const key=btn.dataset.close;if(modalMap[key])btn.onclick=()=>closeModal(modalMap[key]);
});
$$(".modal").forEach(m=>m.addEventListener("click",e=>{if(e.target===m)closeModal("#"+m.id)}));
document.addEventListener("keydown",e=>{
  if(e.key==="Escape"){closeCart();$$(".modal.open").forEach(m=>closeModal("#"+m.id));}
});

const sections=$$("main section[id]"), navLinks=$$(".desktop-nav a");
const obs=new IntersectionObserver(entries=>{
  entries.forEach(ent=>{if(ent.isIntersecting){navLinks.forEach(a=>a.classList.toggle("active",a.getAttribute("href")==="#"+ent.target.id));}});
},{threshold:.35});
sections.forEach(s=>obs.observe(s));

renderProducts(); renderCart(); updateLoginButton();
